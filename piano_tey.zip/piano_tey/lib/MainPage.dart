import 'dart:async';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MainPage extends StatefulWidget {
  @override
  _MainPage createState() => new _MainPage();
}

class _MainPage extends State<MainPage> {

  List<String> result = <String>[];
  String history = '';

  @override
  void initState() {
    super.initState();
    _loadhistory();
  }

  _loadhistory() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      history = (prefs.getString('result') ?? '');
      result = history.split('=');
      for(var r in result){
        print(r);
      }
    });
  }

  delete_all_result() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('result');
    setState(() {
      history = '';
      result = [];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Result'),
      ),
      body: Column(
        children: <Widget>[
          Expanded(
          flex: 8,
          child:
          Container(
            child: ListView.builder(
              itemCount: result.length,
              itemBuilder: (BuildContext context, int index) {
                return ListTile(
                  leading: CircleAvatar(child: Text(index.toString()),),
                  title: Text(result[index]),
                );
              },
            ),
          )
          ),
          Expanded(
              flex: 1,
              child:
              Container(
                child: TextButton (
                  style: ElevatedButton.styleFrom(
                      textStyle: const TextStyle(fontSize: 24)),
                  onPressed: (){
                    // delete_all_result();
                    // Navigator.pop(context, 'remove');
                    Navigator.pop(context, '');
                  },
                  child: Text('刪除資料'),
                ),
              )
          )
        ]

      )
    );
  }
}