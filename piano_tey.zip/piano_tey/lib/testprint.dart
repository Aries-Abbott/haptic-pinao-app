import 'dart:typed_data';
import './printerenum.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import 'dart:io';
import 'package:http/http.dart' as http;

class TestPrint {
  BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;

  sample() async {

    bluetooth.isConnected.then((isConnected) {
      if (isConnected == true) {

        // bluetooth.printCustom("Body left", Size.bold.val, Align.left.val);
        // bluetooth.printCustom("B", Size.medium.val, Align.right.val);

        // bluetooth.printNewLine();
        // print('ff\nff');
        bluetooth.write('1');
      }
    });
  }
}