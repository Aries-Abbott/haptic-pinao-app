import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import './main.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';

// class ChatPage extends StatefulWidget {
//   @override
//   _ChatPage createState() => new _ChatPage();
// }
//
// class _ChatPage extends State<ChatPage> {
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         appBar: AppBar(
//           title: Text('app 介紹'),
//         ),
//         body:
//         Swiper(
//           itemCount: 2,
//           itemBuilder: (BuildContext context, int index){
//             return Card(
//               color: Colors.grey[900],
//               shape: RoundedRectangleBorder(
//                 side: BorderSide(color: Colors.white70, width: 1),
//                 borderRadius: BorderRadius.circular(10),
//               ),
//               margin: EdgeInsets.all(20.0),
//               child: Container(
//                 child: Column(
//                   children: <Widget>[
//                     ListTile(
//                       title: Text(
//                         'example',
//                         style: TextStyle(fontSize: 18, color: Colors.white),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             );
//           },
//           control: SwiperControl(),
//           pagination: SwiperPagination(),
//         ),
//     );
//   }
// }

class hint_page extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Piano Demo',
      home: MyHintPage(),
    );
  }
}

class MyHintPage extends StatefulWidget {
  const MyHintPage({super.key});

  @override
  State<MyHintPage> createState() => _MyHintPageState();
}

class _MyHintPageState extends State<MyHintPage> {

  List<String> image_list = [
    'assets/images/hint_1.png',
    'assets/images/hint_2.png',
    'assets/images/hint_3.png',
    'assets/images/hint_4.png',
    'assets/images/hint_5.png',
    'assets/images/hint_6.png',
    'assets/images/hint_7.png',
    'assets/images/hint_8.png',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text('app 說明')),
        body: Swiper(
          itemCount: 8,
          itemBuilder: (BuildContext context, int index){
            return Card(
              shape: RoundedRectangleBorder(
                side: BorderSide(color: Colors.white70, width: 1),
                borderRadius: BorderRadius.circular(10),
              ),
              margin: EdgeInsets.all(20.0),
              child: Container(
                child:
                Row(
                  children: [
                    Spacer(
                      flex: 1,
                    ),
                    Expanded(
                      flex: 7,
                      child: Stack(
                        alignment: Alignment.centerRight,
                        children: <Widget>[
                          Image.asset(image_list[index],fit: BoxFit.contain),

                        ],
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Container(
                          alignment: Alignment.center,
                          child:
                          TextButton (
                            style: ElevatedButton.styleFrom(textStyle: const TextStyle(fontSize: 24)),
                            onPressed: () {
                              Navigator.push(context, MaterialPageRoute(builder: (context) => MyApp()),);
                            },
                            child: index == 7 ? Text('開始 !!') : Text(''),
                          ),
                        ),

                    )


                  ],
                )

              ),
            );
          },
          itemHeight: 400,
          itemWidth:  300,
          control: SwiperControl(),
          pagination: SwiperPagination(),
        ),
    );
  }
}
//
//
// // import 'dart:async';
// // import 'package:flutter/cupertino.dart';
// // import 'package:flutter/material.dart';
// // import 'package:flutter/services.dart';
// // import 'package:piano/piano.dart';
// // import 'package:flutter_midi/flutter_midi.dart';
// // import './bluetooth_connection.dart';
// // import './MainPage.dart';
// // import 'package:blue_thermal_printer/blue_thermal_printer.dart';
// // import 'package:shared_preferences/shared_preferences.dart';
// //
// //
// //
// // void main() {
// //   WidgetsFlutterBinding.ensureInitialized();
// //   SystemChrome.setPreferredOrientations([
// //     DeviceOrientation.portraitUp,
// //     DeviceOrientation.portraitDown
// //   ]);
// //   SystemChrome.setPreferredOrientations([
// //     DeviceOrientation.landscapeLeft,
// //     DeviceOrientation.landscapeRight
// //   ]);
// //   runApp(MyApp());
// // }
// //
// //
// // class MyApp extends StatelessWidget {
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return const MaterialApp(
// //       title: 'Piano Demo',
// //       home: MyHomePage(),
// //     );
// //   }
// // }
// // class MyHomePage extends StatefulWidget {
// //   const MyHomePage({super.key});
// //
// //   @override
// //   State<MyHomePage> createState() => _MyHomePageState();
// // }
// //
// // class _MyHomePageState extends State<MyHomePage> {
// //
// //   var highlightelist = <NotePosition>[];
// //   final _flutterMidi = FlutterMidi();
// //   BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;
// //   bool _connected = false;
// //   NoteRange noteRange = NoteRange(NotePosition(note: Note.A, octave: 2), NotePosition(note: Note.B, octave: 6));
// //
// //
// //   List all_practice_sheet = [
// //     [ // practice 1  記得下面也要改
// //       [Note.C, 4, 0], [Note.D, 4, 1], [Note.E, 4, 2], [Note.F, 4, 3], [Note.G, 4, 4],
// //       [Note.F, 4, 3], [Note.E, 4, 2], [Note.D, 4, 1], [Note.C, 4, 0],
// //       [Note.C, 4, 0], [Note.D, 4, 1], [Note.E, 4, 2], [Note.F, 4, 3], [Note.G, 4, 4],
// //       [Note.F, 4, 3], [Note.E, 4, 2], [Note.D, 4, 1], [Note.C, 4, 0],
// //       [Note.C, 4, 0], [Note.D, 4, 1], [Note.E, 4, 2], [Note.F, 4, 3], [Note.G, 4, 4],
// //       [Note.F, 4, 3], [Note.E, 4, 2], [Note.D, 4, 1], [Note.C, 4, 0],
// //     ],
// //     [ // practice 2
// //       [Note.C, 4, 0], [Note.D, 4, 1], [Note.E, 4, 2], [Note.E, 4, 2],
// //       [Note.D, 4, 1], [Note.E, 4, 2], [Note.F, 4, 3], [Note.F, 4, 3],
// //       [Note.E, 4, 2], [Note.D, 4, 1], [Note.C, 4, 0], [Note.C, 4, 0], [Note.D, 4, 1],
// //       [Note.D, 4, 1], [Note.E, 4, 2], [Note.F, 4, 3], [Note.F, 4, 3],
// //       [Note.E, 4, 2], [Note.D, 4, 1], [Note.C, 4, 0], [Note.C, 4, 0],
// //       [Note.D, 4, 1], [Note.D, 4, 1], [Note.E, 4, 2], [Note.D, 4, 1],
// //       [Note.C, 4, 0], [Note.G, 4, 4], [Note.C, 4, 0],
// //     ],
// //     [ // practice 3
// //       [Note.C, 4, 0], [Note.C, 4, 0], [Note.C, 4, 0], [Note.E, 4, 2],
// //       [Note.D, 4, 1], [Note.D, 4, 1], [Note.D, 4, 1], [Note.F, 4, 3],
// //       [Note.E, 4, 2], [Note.E, 4, 2], [Note.D, 4, 1], [Note.D, 4, 1], [Note.C, 4, 0],
// //       [Note.E, 4, 2], [Note.E, 4, 2], [Note.E, 4, 2], [Note.E, 4, 2], [Note.G, 4, 4], [Note.F, 4, 3],
// //       [Note.D, 4, 1], [Note.D, 4, 1], [Note.D, 4, 1], [Note.D, 4, 1], [Note.F, 4, 3], [Note.E, 4, 2],
// //       [Note.C, 4, 0], [Note.C, 4, 0], [Note.C, 4, 0], [Note.E, 4, 2],
// //       [Note.D, 4, 1], [Note.D, 4, 1], [Note.D, 4, 1], [Note.F, 4, 3],
// //       [Note.E, 4, 2], [Note.E, 4, 2], [Note.D, 4, 1], [Note.D, 4, 1], [Note.C, 4, 0],
// //     ],
// //     [ // practice 4
// //       [Note.C, 4, 0], [Note.E, 4, 2], [Note.D, 4, 1], [Note.F, 4, 3], [Note.E, 4, 2], [Note.C, 4, 0], [Note.D, 4, 1],
// //       [Note.C, 4, 0], [Note.E, 4, 2], [Note.D, 4, 1], [Note.F, 4, 3], [Note.E, 4, 2], [Note.D, 4, 1], [Note.C, 4, 0],
// //       [Note.D, 4, 1], [Note.E, 4, 2], [Note.C, 4, 0], [Note.G, 4, 4], [Note.F, 4, 3], [Note.E, 4, 2], [Note.D, 4, 1],
// //       [Note.C, 4, 0], [Note.E, 4, 2], [Note.D, 4, 1], [Note.F, 4, 3], [Note.E, 4, 2], [Note.D, 4, 1], [Note.C, 4, 0],
// //     ],
// //     [ // practice 5
// //       [Note.G, 4, 4], [Note.F, 4, 3], [Note.E, 4, 2],
// //       [Note.D, 4, 1], [Note.E, 4, 2], [Note.F, 4, 3], [Note.D, 4, 1], [Note.C, 4, 0],
// //       [Note.E, 4, 2], [Note.F, 4, 3], [Note.G, 4, 4], [Note.E, 4, 2],
// //       [Note.D, 4, 1], [Note.E, 4, 2], [Note.F, 4, 3], [Note.D, 4, 1],
// //       [Note.E, 4, 2], [Note.F, 4, 3], [Note.G, 4, 4], [Note.E, 4, 2],
// //       [Note.D, 4, 1], [Note.E, 4, 2], [Note.F, 4, 3], [Note.D, 4, 1],
// //       [Note.G, 4, 4], [Note.F, 4, 3], [Note.E, 4, 2],
// //       [Note.D, 4, 1], [Note.E, 4, 2], [Note.F, 4, 3], [Note.D, 4, 1], [Note.C, 4, 0],
// //     ],
// //     [ // practice 6
// //       [Note.E, 4, 2], [Note.G, 4, 4], [Note.G, 4, 4], [Note.G, 4, 4],
// //       [Note.E, 4, 2], [Note.G, 4, 4], [Note.G, 4, 4], [Note.G, 4, 4],
// //       [Note.E, 4, 2], [Note.G, 4, 4], [Note.D, 4, 1], [Note.G, 4, 4], [Note.E, 4, 2], [Note.C, 4, 0], [Note.D, 4, 1],
// //       [Note.E, 4, 2], [Note.G, 4, 4], [Note.G, 4, 4], [Note.G, 4, 4],
// //       [Note.E, 4, 2], [Note.G, 4, 4], [Note.G, 4, 4], [Note.G, 4, 4],
// //       [Note.E, 4, 2], [Note.G, 4, 4], [Note.F, 4, 3], [Note.D, 4, 1], [Note.C, 4, 0], [Note.E, 4, 2], [Note.C, 4, 0],
// //       [Note.D, 4, 1], [Note.F, 4, 3], [Note.F, 4, 3], [Note.F, 4, 3],
// //       [Note.D, 4, 1], [Note.F, 4, 3], [Note.F, 4, 3], [Note.F, 4, 3],
// //       [Note.E, 4, 2], [Note.D, 4, 1], [Note.C, 4, 0], [Note.E, 4, 2], [Note.G, 4, 4], [Note.E, 4, 2], [Note.D, 4, 1],
// //       [Note.E, 4, 2], [Note.G, 4, 4], [Note.G, 4, 4], [Note.G, 4, 4],
// //       [Note.E, 4, 2], [Note.G, 4, 4], [Note.G, 4, 4], [Note.G, 4, 4],
// //       [Note.E, 4, 2], [Note.G, 4, 4], [Note.F, 4, 3], [Note.D, 4, 1], [Note.C, 4, 0], [Note.E, 4, 2], [Note.C, 4, 0],
// //     ],
// //     [ // practice 7
// //       [Note.C, 4, 0], [Note.C, 4, 0], [Note.D, 4, 1], [Note.E, 4, 2], [Note.E, 4, 2],
// //       [Note.D, 4, 1], [Note.G, 4, 4], [Note.G, 4, 4], [Note.F, 4, 3], [Note.E, 4, 2], [Note.D, 4, 1],
// //       [Note.C, 4, 0], [Note.C, 4, 0], [Note.D, 4, 1], [Note.E, 4, 2], [Note.E, 4, 2],
// //       [Note.D, 4, 1], [Note.G, 4, 4], [Note.G, 4, 4],
// //       [Note.C, 4, 0], [Note.C, 4, 0], [Note.D, 4, 1], [Note.E, 4, 2], [Note.E, 4, 2],
// //       [Note.D, 4, 1], [Note.G, 4, 4], [Note.G, 4, 4], [Note.F, 4, 3], [Note.E, 4, 2], [Note.D, 4, 1],
// //       [Note.C, 4, 0], [Note.C, 4, 0], [Note.D, 4, 1], [Note.E, 4, 2], [Note.E, 4, 2],
// //       [Note.D, 4, 1], [Note.G, 4, 4], [Note.C, 4, 0],
// //       [Note.D, 4, 1], [Note.G, 4, 4], [Note.G, 4, 4], [Note.G, 4, 4],
// //       [Note.D, 4, 1], [Note.G, 4, 4], [Note.G, 4, 4], [Note.G, 4, 4],
// //       [Note.D, 4, 1], [Note.G, 4, 4], [Note.E, 4, 2], [Note.C, 4, 0], [Note.D, 4, 1], [Note.G, 4, 4], [Note.G, 4, 4],
// //       [Note.C, 4, 0], [Note.C, 4, 0], [Note.D, 4, 1], [Note.E, 4, 2], [Note.E, 4, 2],
// //       [Note.D, 4, 1], [Note.G, 4, 4], [Note.G, 4, 4], [Note.F, 4, 3], [Note.E, 4, 2], [Note.D, 4, 1],
// //       [Note.C, 4, 0], [Note.C, 4, 0], [Note.D, 4, 1], [Note.E, 4, 2], [Note.E, 4, 2],
// //       [Note.D, 4, 1], [Note.G, 4, 4], [Note.C, 4, 0],
// //     ],
// //   ];
// //
// //   List lock = [true, false, false, false, false, false, true];
// //
// //   List now_sheet = [ // practice 1  下面在這邊!! 改這裡
// //     [Note.C, 4, 0], [Note.D, 4, 1], [Note.E, 4, 2], [Note.F, 4, 3], [Note.G, 4, 4],
// //     [Note.F, 4, 3], [Note.E, 4, 2], [Note.D, 4, 1], [Note.C, 4, 0],
// //     [Note.C, 4, 0], [Note.D, 4, 1], [Note.E, 4, 2], [Note.F, 4, 3], [Note.G, 4, 4],
// //     [Note.F, 4, 3], [Note.E, 4, 2], [Note.D, 4, 1], [Note.C, 4, 0],
// //     [Note.C, 4, 0], [Note.D, 4, 1], [Note.E, 4, 2], [Note.F, 4, 3], [Note.G, 4, 4],
// //     [Note.F, 4, 3], [Note.E, 4, 2], [Note.D, 4, 1], [Note.C, 4, 0],
// //   ];
// //
// //   List difficalty_level = [1.2, 1.0, 0.66];
// //   int difficalty = 0;
// //   bool play_button_visibility = true;
// //
// //   int now_play_index = 0;
// //   int now_sheet_index = 0;
// //   List note_list = [[Note.C, 4], [Note.D, 4], [Note.E, 4], [Note.F, 4], [Note.G, 4], [Note.C, 4], [Note.D, 4]];
// //
// //   double used_time = 0.0;
// //   double total_used_time = 0.0;
// //   List note_offset = [0.25, 0.4, 0.55, 0.7, 0.85, 1.0, 1.25];
// //   Timer? _timer = null;
// //   Color note_color = Colors.orange;
// //   bool is_pressed = false;
// //   bool is_test_started = false;
// //   bool is_practice_started = false;
// //   bool is_practice_exam = false;
// //   bool is_example_started = false;
// //   bool is_not_last_level = true;
// //   var wrong_play_number = 0;
// //   var no_play_number = 0;
// //   var play_number = 0;
// //   double used_note_time = 0;
// //   String history = '';
// //
// //   List hand_hint_text = [
// //     '大拇指',
// //     '食指',
// //     '中指',
// //     '無名指',
// //     '小拇指',
// //   ];
// //   List image_path = [
// //     'assets/images/thumb2.png',
// //     'assets/images/fore_finger2.png',
// //     'assets/images/middle_finger2.png',
// //     'assets/images/ring_finger2.png',
// //     'assets/images/little_finger2.png'
// //   ];
// //
// //   final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
// //   String key = '';
// //
// //   @override
// //   void initState() {
// //     load('assets/sf2/Piano.sf2');
// //     super.initState();
// //     device_listener();
// //     _loadhistory();
// //   }
// //
// //   _loadhistory() async {
// //     SharedPreferences prefs = await SharedPreferences.getInstance();
// //     setState(() {
// //       history = (prefs.getString('result') ?? '');
// //     });
// //   }
// //
// //   void device_listener(){
// //     bluetooth.onStateChanged().listen((state) {
// //       switch (state) {
// //         case BlueThermalPrinter.CONNECTED:
// //           setState(() {
// //             _connected = true;
// //             print("bluetooth device state: connected");
// //           });
// //           break;
// //         case BlueThermalPrinter.DISCONNECTED:
// //           setState(() {
// //             _connected = false;
// //             print("bluetooth device state: disconnected");
// //           });
// //           break;
// //         case BlueThermalPrinter.DISCONNECT_REQUESTED:
// //           setState(() {
// //             _connected = false;
// //             print("bluetooth device state: disconnect requested");
// //           });
// //           break;
// //         case BlueThermalPrinter.STATE_TURNING_OFF:
// //           setState(() {
// //             _connected = false;
// //             print("bluetooth device state: bluetooth turning off");
// //           });
// //           break;
// //         case BlueThermalPrinter.STATE_OFF:
// //           setState(() {
// //             _connected = false;
// //             print("bluetooth device state: bluetooth off");
// //           });
// //           break;
// //         case BlueThermalPrinter.STATE_ON:
// //           setState(() {
// //             _connected = false;
// //             print("bluetooth device state: bluetooth on");
// //           });
// //           break;
// //         case BlueThermalPrinter.STATE_TURNING_ON:
// //           setState(() {
// //             _connected = false;
// //             print("bluetooth device state: bluetooth turning on");
// //           });
// //           break;
// //         case BlueThermalPrinter.ERROR:
// //           setState(() {
// //             _connected = false;
// //             print("bluetooth device state: error");
// //           });
// //           break;
// //         default:
// //           print(state);
// //           break;
// //       }
// //     });
// //   }
// //
// //   void load(String asset) async {
// //     _flutterMidi.unmute(); // Optionally Unmute
// //     ByteData _byte = await rootBundle.load(asset);
// //     _flutterMidi.prepare(sf2: _byte);
// //   }
// //
// //   void _play(int midi) {
// //     _flutterMidi.playMidiNote(midi: midi);
// //   }
// //
// //   void start_test(){
// //     setState(() {
// //       play_button_visibility = false;
// //       is_test_started = true;
// //     });
// //     _timer = Timer.periodic(const Duration(milliseconds:10), (timer){
// //       update_test([0]);
// //     });
// //   }
// //
// //   void start_example(){
// //     setState(() {
// //       play_button_visibility = false;
// //       is_example_started = true;
// //     });
// //     _timer = Timer.periodic(const Duration(milliseconds:10), (timer){
// //       update_example();
// //     });
// //   }
// //
// //   void start_count_time(){
// //     setState(() {
// //       play_button_visibility = false;
// //     });
// //     _timer = Timer.periodic(const Duration(milliseconds:10), (timer){
// //       used_note_time = used_note_time + 0.01;
// //     });
// //   }
// //
// //   void stop_timer(){
// //     _timer?.cancel();
// //   }
// //
// //   _show_test_Dialog() {
// //     showDialog(
// //         context: context,
// //         barrierDismissible: false,
// //         builder: (context) => StatefulBuilder(
// //             builder: (context, dialogStateState) => SimpleDialog(
// //               title: Text('Level ' + (difficalty + 1).toString() + ' result', style: TextStyle(fontSize: 32), textAlign: TextAlign.center),
// //               contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
// //               children: <Widget>[
// //                 Container(
// //                   height: MediaQuery.of(context).size.height / 8,
// //                   width: MediaQuery.of(context).size.width / 2,
// //                   child: Text('\t\t 未彈奏次數 :  ' + no_play_number.toString(), style: const TextStyle(fontSize: 24)),
// //                 ),
// //                 Container(
// //                   height: MediaQuery.of(context).size.height / 8,
// //                   width: MediaQuery.of(context).size.width / 2,
// //                   child: Text('\t\t彈錯次數 :  ' + wrong_play_number.toString(), style: const TextStyle(fontSize: 24)),
// //                 ),
// //                 Container(
// //                   height: MediaQuery.of(context).size.height / 8,
// //                   width: MediaQuery.of(context).size.width / 2,
// //                   child: Text('\t\t正確率 :  ' + ((now_sheet.length - no_play_number - wrong_play_number) / now_sheet.length * 100).toStringAsFixed(2) + ' %', style: const TextStyle(fontSize: 24)),
// //                 ),
// //                 Container(
// //                   height: MediaQuery.of(context).size.height / 8,
// //                   width: MediaQuery.of(context).size.width / 2,
// //                   child: const Text('\t\t簡評 :  ', style: TextStyle(fontSize: 24)),
// //                 ),
// //                 Container(
// //                   height: MediaQuery.of(context).size.height / 16,
// //                   width: MediaQuery.of(context).size.width / 2,
// //                   child:
// //                   Row(
// //                       mainAxisAlignment: MainAxisAlignment.spaceAround,
// //                       children: <Widget>[
// //                         TextButton(
// //                             onPressed: (){
// //                               save_result((now_sheet_index + 1).toString(), '速度練習', wrong_play_number.toString(), ((now_sheet.length - no_play_number - wrong_play_number) / now_sheet.length * 100).toStringAsFixed(2), no_play_number.toString(), difficalty.toString(), (total_used_time / now_sheet.length).toStringAsFixed(2));
// //                               set_new_round(context, false);
// //                               Navigator.pop(context);
// //                             },
// //                             child: const Text('practice again', style: TextStyle(fontSize: 24))
// //                         ),
// //                         Visibility(
// //                           visible: is_not_last_level,
// //                           child:TextButton(
// //                               onPressed: (){
// //                                 save_result((now_sheet_index + 1).toString(), '速度練習', wrong_play_number.toString(), ((now_sheet.length - no_play_number - wrong_play_number) / now_sheet.length * 100).toStringAsFixed(2), no_play_number.toString(), difficalty.toString(), (total_used_time / now_sheet.length).toStringAsFixed(2));
// //                                 set_new_round(context, true);
// //                                 Navigator.pop(context);
// //                               },
// //                               child: const Text('next level', style: TextStyle(fontSize: 24))),
// //                         ),
// //                         Visibility(
// //                           visible: difficalty == 2 && now_sheet_index < all_practice_sheet.length - 2,
// //                           child:TextButton(
// //                               onPressed: (){
// //                                 lock[now_sheet_index + 1] = true;
// //                                 set_new_sheet(now_sheet_index + 1);
// //                                 Navigator.pop(context);
// //                               },
// //                               child: const Text('next practice sheet', style: TextStyle(fontSize: 24))),
// //                         ),
// //                       ]
// //                   ),
// //                 ),
// //               ],
// //             )
// //         )
// //     );
// //   }
// //
// //   _show_practice_Dialog() {
// //     showDialog(
// //         context: context,
// //         barrierDismissible: false,
// //         builder: (context) => StatefulBuilder(
// //             builder: (context, dialogStateState) => SimpleDialog(
// //               title: Text('Practice result', style: TextStyle(fontSize: 32), textAlign: TextAlign.center),
// //               contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
// //               children: <Widget>[
// //                 Container(
// //                   height: MediaQuery.of(context).size.height / 8,
// //                   width: MediaQuery.of(context).size.width / 2,
// //                   child: Text('\t\t彈錯次數 :  ' + wrong_play_number.toString(), style: const TextStyle(fontSize: 24)),
// //                 ),
// //                 Container(
// //                   height: MediaQuery.of(context).size.height / 8,
// //                   width: MediaQuery.of(context).size.width / 2,
// //                   child: Text('\t\t正確率 :  ' + ((play_number - wrong_play_number) / play_number * 100).toStringAsFixed(2) + ' %', style: const TextStyle(fontSize: 24)),
// //                 ),
// //                 Container(
// //                   height: MediaQuery.of(context).size.height / 8,
// //                   width: MediaQuery.of(context).size.width / 2,
// //                   child: const Text('\t\t簡評 :  ', style: TextStyle(fontSize: 24)),
// //                 ),
// //                 Container(
// //                   height: MediaQuery.of(context).size.height / 16,
// //                   width: MediaQuery.of(context).size.width / 2,
// //                   child:
// //                   Row(
// //                       mainAxisAlignment: MainAxisAlignment.spaceAround,
// //                       children: <Widget>[
// //                         TextButton(
// //                             onPressed: (){
// //                               save_result((now_sheet_index + 1).toString(), '個別音符練習', wrong_play_number.toString(), ((play_number - wrong_play_number) / play_number * 100).toStringAsFixed(2), '', '', (used_note_time / now_sheet.length).toStringAsFixed(2));
// //                               set_new_round(context, false);
// //                               Navigator.pop(context);
// //                             },
// //                             child: const Text('back', style: TextStyle(fontSize: 24))
// //                         ),
// //                       ]
// //                   ),
// //                 ),
// //               ],
// //             )
// //         )
// //     );
// //   }
// //
// //   _show_exam_Dialog() {
// //     showDialog(
// //         context: context,
// //         barrierDismissible: false,
// //         builder: (context) => StatefulBuilder(
// //             builder: (context, dialogStateState) => SimpleDialog(
// //               title: Text('Exam result', style: TextStyle(fontSize: 32), textAlign: TextAlign.center),
// //               contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
// //               children: <Widget>[
// //                 Container(
// //                   height: MediaQuery.of(context).size.height / 8,
// //                   width: MediaQuery.of(context).size.width / 2,
// //                   child: Text('\t\t彈錯次數 :  ' + wrong_play_number.toString(), style: const TextStyle(fontSize: 24)),
// //                 ),
// //                 Container(
// //                   height: MediaQuery.of(context).size.height / 8,
// //                   width: MediaQuery.of(context).size.width / 2,
// //                   child: Text('\t\t正確率 :  ' + ((now_sheet.length - wrong_play_number) / now_sheet.length * 100).toStringAsFixed(2) + ' %', style: const TextStyle(fontSize: 24)),
// //                 ),
// //                 Container(
// //                   height: MediaQuery.of(context).size.height / 8,
// //                   width: MediaQuery.of(context).size.width / 2,
// //                   child: const Text('\t\t簡評 :  ', style: TextStyle(fontSize: 24)),
// //                 ),
// //                 Container(
// //                   height: MediaQuery.of(context).size.height / 16,
// //                   width: MediaQuery.of(context).size.width / 2,
// //                   child:
// //                   Row(
// //                       mainAxisAlignment: MainAxisAlignment.spaceAround,
// //                       children: <Widget>[
// //                         TextButton(
// //                             onPressed: (){
// //                               save_result((now_sheet_index + 1).toString(), '測驗', wrong_play_number.toString(), ((now_sheet.length - wrong_play_number) / now_sheet.length * 100).toStringAsFixed(2), '', '', (used_note_time / now_sheet.length).toStringAsFixed(2));
// //                               set_new_round(context, false);
// //                               Navigator.pop(context);
// //                             },
// //                             child: const Text('back', style: TextStyle(fontSize: 24))
// //                         ),
// //                       ]
// //                   ),
// //                 ),
// //               ],
// //             )
// //         )
// //     );
// //   }
// //
// //   save_result(now_sheet_index, mode, wrong_number, correct_rate, no_play_number, difficalty, avarage_cost_time) async {
// //     var now = DateTime.now();
// //     SharedPreferences prefs = await SharedPreferences.getInstance();
// //     if(mode == '教學示範'){
// //       history = history + '時間 : ' + now.toString() + ' 樂譜 : ' + now_sheet_index + ' 模式 : ' + mode + '=';
// //       prefs.setString('result', history);
// //     }
// //     else if(no_play_number == '') {
// //       history = history + '時間 : ' + now.toString() + ' 樂譜 : ' + now_sheet_index + ' 模式 : ' + mode + ' 彈錯次數 : ' + wrong_number + ' 正確率 : ' + correct_rate + ' 平均花費時間 : ' + avarage_cost_time + '=';
// //       prefs.setString('result', history);
// //     }
// //     else{
// //       history = history + '時間 : ' + now.toString() + ' 樂譜 : ' + now_sheet_index + ' 模式 : ' + mode + ' 彈錯次數 : ' + wrong_number + ' 正確率 : ' + correct_rate + ' 未彈奏次數 : ' + no_play_number + ' 難度 : ' + difficalty + ' 平均花費時間 : ' + avarage_cost_time + '=';
// //       prefs.setString('result', history);
// //     }
// //   }
// //
// //   void set_new_round(context, if_next_level){
// //     setState(() {
// //       if(if_next_level){
// //         print(difficalty);
// //         if(difficalty < 1){
// //           is_not_last_level = true;
// //           difficalty = difficalty + 1;
// //         }
// //         else if(difficalty == 1){
// //           difficalty = difficalty + 1;
// //           is_not_last_level = false;
// //         }
// //       }
// //       print(is_not_last_level);
// //       play_button_visibility = true;
// //       now_play_index = 0;
// //       note_list = all_practice_sheet[now_sheet_index].sublist(0, 7);
// //       used_time = 0.0;
// //       total_used_time = 0.0;
// //       note_color = Colors.orange;
// //       is_pressed = false;
// //       is_test_started = false;
// //       is_example_started = false;
// //       is_practice_started = false;
// //       is_practice_exam = false;
// //       note_offset = [0.25, 0.4, 0.55, 0.7, 0.85, 1.0, 1.25];
// //       highlightelist = [];
// //       wrong_play_number = 0;
// //       no_play_number = 0;
// //       play_number = 0;
// //     });
// //   }
// //
// //   void set_new_sheet(sheet_number){
// //     setState(() {
// //       is_not_last_level = true;
// //       difficalty = 0;
// //       play_button_visibility = true;
// //       now_play_index = 0;
// //       now_sheet_index = sheet_number;
// //       note_list = all_practice_sheet[sheet_number].sublist(0, 7);
// //       now_sheet = all_practice_sheet[now_sheet_index];
// //       used_time = 0.0;
// //       total_used_time = 0.0;
// //       note_color = Colors.orange;
// //       is_pressed = false;
// //       is_test_started = false;
// //       is_example_started = false;
// //       is_practice_started = false;
// //       is_practice_exam = false;
// //       note_offset = [0.25, 0.4, 0.55, 0.7, 0.85, 1.0, 1.25];
// //       highlightelist = [];
// //       wrong_play_number = 0;
// //       no_play_number = 0;
// //     });
// //   }
// //
// //   void update_exam(input){
// //     setState(() {
// //
// //       note_color = Colors.orange;
// //       highlightelist = [];
// //       if(input.note != now_sheet[now_play_index][0] || input.octave != now_sheet[now_play_index][1]){
// //         wrong_play_number = wrong_play_number + 1;
// //       }
// //
// //       if (now_play_index == now_sheet.length - 1){
// //         stop_timer();
// //         _show_exam_Dialog();
// //       }
// //       else{
// //         now_play_index = now_play_index + 1;
// //         for (var i = 0; i < 7; i++) {
// //           if (now_play_index + i < now_sheet.length) {
// //             note_list[i] = now_sheet[now_play_index + i];
// //           }
// //           else {
// //             note_offset[i] = 20; // 移到螢幕外
// //           }
// //         }
// //       }
// //
// //     });
// //   }
// //
// //   void update_practice(input){
// //     setState(() {
// //       play_number = play_number + 1;
// //
// //       if(input.note == now_sheet[now_play_index][0] && input.octave == now_sheet[now_play_index][1]){
// //         note_color = Colors.orange;
// //         highlightelist = [];
// //         if (now_play_index == now_sheet.length - 1){
// //           print(used_note_time);
// //           stop_timer();
// //           _show_practice_Dialog();
// //         }
// //         else{
// //           now_play_index = now_play_index + 1;
// //           for (var i = 0; i < 7; i++) {
// //             if (now_play_index + i < now_sheet.length) {
// //               note_list[i] = now_sheet[now_play_index + i];
// //             }
// //             else {
// //               note_offset[i] = 20; // 移到螢幕外
// //             }
// //           }
// //         }
// //       }
// //       else{
// //         note_color = Colors.red;
// //         wrong_play_number = wrong_play_number + 1;
// //         highlightelist = [NotePosition(note: now_sheet[now_play_index][0], octave: now_sheet[now_play_index][1])];
// //       }
// //     });
// //   }
// //
// //   void update_test(input){
// //     setState(() {
// //       if (input[0] == 0) {
// //         if (used_time >= difficalty_level[difficalty]) { // 當下音符時間結束
// //           if (is_pressed == false){ // 來不及彈
// //             total_used_time = total_used_time + used_time;
// //             no_play_number = no_play_number + 1;
// //           }
// //           if (now_play_index == now_sheet.length - 1) { // 全部彈完了
// //             stop_timer();
// //             if(no_play_number + wrong_play_number > 0){
// //               is_not_last_level = false;
// //             }
// //             else{
// //               if(difficalty < 2){
// //                 is_not_last_level = true;
// //               }
// //             }
// //             _show_test_Dialog();
// //           }
// //           else { // 還沒彈完
// //             highlightelist = [];
// //             note_color = Colors.orange;
// //             is_pressed = false;
// //             used_time = 0;
// //             now_play_index = now_play_index + 1;
// //             for (var i = 0; i < 7; i++) {
// //               if (now_play_index + i < now_sheet.length) {
// //                 note_offset[i] = 0.25 + (0.15 * i) + (-(0.15 / difficalty_level[difficalty]) * 0.01);
// //                 note_list[i] = now_sheet[now_play_index + i];
// //               }
// //               else {
// //                 note_offset[i] = 20; // 移到螢幕外
// //               }
// //             }
// //           }
// //         }
// //         else { // 還在當下音符時間，只是需要位移音符
// //           used_time = used_time + 0.01;
// //           for (var i = 0; i < 7; i++) {
// //             note_offset[i] =
// //                 note_offset[i] + (-(0.15 / difficalty_level[difficalty]) * 0.01);
// //           }
// //         }
// //       }
// //       else if(is_pressed == false){
// //         total_used_time = total_used_time + used_time;
// //         is_pressed = true;
// //         if(input[1].note == now_sheet[now_play_index][0] && input[1].octave == now_sheet[now_play_index][1]){
// //           note_color = Colors.green;
// //         }
// //         else{
// //           note_color = Colors.red;
// //           wrong_play_number = wrong_play_number + 1;
// //           highlightelist = [NotePosition(note: now_sheet[now_play_index][0], octave: now_sheet[now_play_index][1])];
// //         }
// //       }
// //     });
// //   }
// //
// //   void update_example(){
// //
// //     setState(() {
// //       if (used_time >= difficalty_level[difficalty] / 2 && is_pressed == false){
// //         _play(NotePosition(note: now_sheet[now_play_index][0], octave: now_sheet[now_play_index][1]).pitch);
// //         highlightelist = [NotePosition(note: now_sheet[now_play_index][0], octave: now_sheet[now_play_index][1])];
// //         bluetooth.write(now_sheet[now_play_index][2].toString());
// //         note_color = Colors.green;
// //         is_pressed = true;
// //       }
// //       if (used_time >= difficalty_level[difficalty]) { // 當下音符時間結束
// //         if (now_play_index == now_sheet.length - 1) { // 全部彈完了
// //           stop_timer();
// //           set_new_round(context, false);
// //         }
// //         else { // 還沒彈完
// //           highlightelist = [];
// //           note_color = Colors.orange;
// //           is_pressed = false;
// //           used_time = 0;
// //           now_play_index = now_play_index + 1;
// //           for (var i = 0; i < 7; i++) {
// //             if (now_play_index + i < now_sheet.length) {
// //               note_offset[i] = 0.25 + (0.15 * i) + (-(0.15 / difficalty_level[difficalty]) * 0.01);
// //               note_list[i] = now_sheet[now_play_index + i];
// //             }
// //             else {
// //               note_offset[i] = 20; // 移到螢幕外
// //             }
// //           }
// //         }
// //       }
// //       else { // 還在當下音符時間，只是需要位移音符
// //         used_time = used_time + 0.01;
// //         for (var i = 0; i < 7; i++) {
// //           note_offset[i] =
// //               note_offset[i] + (-(0.15 / difficalty_level[difficalty]) * 0.01);
// //         }
// //       }
// //     });
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(title: now_sheet_index == all_practice_sheet.length - 1 ? const Text('測驗') : Text('樂譜 : ' + (now_sheet_index + 1).toString() + ' 難度 : ' + (difficalty + 1).toString())),
// //       body:
// //
// //       Row(
// //           children: <Widget>[
// //             Expanded(
// //               flex: 1,
// //               child:
// //
// //               Column(
// //                   children: <Widget>[
// //                     Expanded(
// //                       flex: 2,
// //                       child: Text(''),
// //                     ),
// //                     Expanded(
// //                         flex: 1,
// //                         child:
// //                         Container(
// //                           alignment: Alignment.bottomCenter,
// //                           child: Text('請注意指法提示', style: TextStyle(fontSize: 24)),
// //                         )
// //                     ),
// //                     Expanded(
// //                       flex: 3,
// //                       child:
// //                       Container(
// //                         child: Image.asset(image_path[now_sheet[now_play_index][2]]),
// //                       ),
// //                     ),
// //                     Expanded(
// //                       flex: 1,
// //                       child:
// //                       Container(
// //                         child: Text(hand_hint_text[now_sheet[now_play_index][2]], style: TextStyle(fontSize: 24)),
// //                       ),
// //                     ),
// //                     Expanded(
// //                       flex: 2,
// //                       child: Text(''),
// //                     ),
// //                   ]
// //               ),
// //             ),
// //             Expanded(
// //               flex: 5,
// //               child:
// //               Column(
// //                 children: <Widget>[
// //                   Expanded(
// //                     flex: 1,
// //                     child: Text(''),
// //                   ),
// //                   Expanded(
// //                     flex: 3,
// //                     child:
// //                     Container(
// //                       height: MediaQuery.of(context).size.height,
// //                       child: ClefImage(
// //                           clef: Clef.Treble,
// //                           noteRange: noteRange,
// //                           noteImages :
// //                           [
// //                             NoteImage(notePosition: NotePosition(note: note_list[0][0], octave: note_list[0][1]), offset : note_offset[0].toDouble(), color : note_color),
// //                             NoteImage(notePosition: NotePosition(note: note_list[1][0], octave: note_list[1][1]), offset : note_offset[1].toDouble()),
// //                             NoteImage(notePosition: NotePosition(note: note_list[2][0], octave: note_list[2][1]), offset : note_offset[2].toDouble()),
// //                             NoteImage(notePosition: NotePosition(note: note_list[3][0], octave: note_list[3][1]), offset : note_offset[3].toDouble()),
// //                             NoteImage(notePosition: NotePosition(note: note_list[4][0], octave: note_list[4][1]), offset : note_offset[4].toDouble()),
// //                             NoteImage(notePosition: NotePosition(note: note_list[5][0], octave: note_list[5][1]), offset : note_offset[5].toDouble()),
// //                             NoteImage(notePosition: NotePosition(note: note_list[6][0], octave: note_list[6][1]), offset : note_offset[6].toDouble()),
// //                           ],
// //                           clefColor : Colors.black,
// //                           noteColor : Colors.black,
// //                           size : Size(MediaQuery.of(context).size.width, 1)
// //                       ),
// //                     ),
// //                   ),
// //                   Expanded(
// //                     flex: 1,
// //                     child: Text(''),
// //                   ),
// //                   Expanded(
// //                       flex: 1,
// //                       child:
// //                       Visibility(
// //                         visible: play_button_visibility,
// //                         child: Container(
// //                           alignment: Alignment.topCenter,
// //                           child: Row(
// //                               mainAxisAlignment: MainAxisAlignment.spaceAround,
// //                               children: _connected == true ?
// //                               now_sheet_index == all_practice_sheet.length - 1 ?
// //                               <Widget>[
// //                                 TextButton (
// //                                   style: ElevatedButton.styleFrom(
// //                                       textStyle: const TextStyle(fontSize: 24)),
// //                                   onPressed: (){
// //                                     setState(() {
// //                                       is_practice_exam = true;
// //                                       play_button_visibility = false;
// //                                       start_count_time();
// //                                     });
// //                                   },
// //                                   child: Text('測驗 !'),
// //                                 ),
// //                               ]:
// //                               <Widget>[
// //                                 TextButton (
// //                                   style: ElevatedButton.styleFrom(
// //                                       textStyle: const TextStyle(fontSize: 24)),
// //                                   onPressed: (){
// //                                     setState(() {
// //                                       is_practice_started = true;
// //                                       play_button_visibility = false;
// //                                       start_count_time();
// //                                     });
// //                                   },
// //                                   child: Text('個別音符練習 !'),
// //                                 ),
// //                                 TextButton (
// //                                   style: ElevatedButton.styleFrom(textStyle: const TextStyle(fontSize: 24)),
// //                                   onPressed: (){
// //                                     start_example();
// //                                     save_result((now_sheet_index + 1).toString(), '教學示範', wrong_play_number.toString(), ((now_sheet.length - no_play_number - wrong_play_number) / now_sheet.length * 100).toStringAsFixed(2), no_play_number.toString(), difficalty.toString(), (total_used_time / now_sheet.length).toStringAsFixed(2));
// //                                   },
// //                                   child: Text('教學示範 !'),
// //                                 ),
// //                                 TextButton (
// //                                   style: ElevatedButton.styleFrom(textStyle: const TextStyle(fontSize: 24)),
// //                                   onPressed: start_test,
// //                                   child: Text('速度練習 !'),
// //                                 ),
// //                               ] :
// //                               <Widget>[
// //                                 TextButton (
// //                                   style: ElevatedButton.styleFrom(textStyle: const TextStyle(fontSize: 24)),
// //                                   onPressed: () async {bluetooth = await Navigator.push(context, MaterialPageRoute(builder: (context) => get_bluetooth_page()),);},
// //                                   child: Text('Doesn\'t connect to Arduino yet. Please set Arduino device first !'),),
// //                               ]
// //                           ),
// //                         ),
// //                       )
// //                   ),
// //                   Expanded(
// //                       flex: 4,
// //                       child: Center(
// //                         child: InteractivePiano(
// //                           highlightedNotes: highlightelist,
// //                           naturalColor: Colors.white,
// //                           accidentalColor: Colors.black,
// //                           keyWidth: MediaQuery.of(context).size.width / 10 / 6 * 5,
// //                           noteRange: NoteRange(NotePosition(note: Note.B, octave: 3), NotePosition(note: Note.D, octave: 5)),
// //                           // NoteRange.forClefs([
// //                           //   Clef.Alto,
// //                           // ]),
// //                           onNotePositionTapped: (position){
// //                             if(is_example_started == false){
// //                               _play(position.pitch);
// //                             }
// //                             if(is_test_started){
// //                               bluetooth.write(now_sheet[now_play_index][2].toString());
// //                               update_test([1, position]);
// //                             }
// //                             if(is_practice_started){
// //                               bluetooth.write(now_sheet[now_play_index][2].toString());
// //                               update_practice(position);
// //                             }
// //                             if(is_practice_exam){
// //                               bluetooth.write(now_sheet[now_play_index][2].toString());
// //                               update_exam(position);
// //                             }
// //                             // print(position);
// //                           },
// //                         ),
// //                       )
// //                   ),
// //                 ],
// //               ),
// //             ),
// //           ]
// //       ),
// //
// //       drawer: Drawer(
// //         child: ListView(
// //           // Important: Remove any padding from the ListView.
// //           padding: EdgeInsets.zero,
// //           children: [
// //             DrawerHeader(
// //               decoration: const BoxDecoration(color: Colors.blue),
// //               child: Container(
// //                 alignment: Alignment.center,
// //                 child: TextButton (
// //                   style: TextButton.styleFrom(
// //                     primary: Colors.white, // Text Color
// //                   ),
// //
// //                   onPressed: () async {
// //                     stop_timer();
// //                     set_new_round(context, false);
// //                     history = await Navigator.push(context, MaterialPageRoute(builder: (context) => MainPage()),);
// //                   },
// //                   child: const Text('check result !', style: TextStyle(fontSize: 24),),
// //                 ),
// //               ),
// //             ),
// //             Visibility(
// //               visible: lock[0],
// //               child:
// //               ListTile(
// //                 title: const Text('練習 1', style: TextStyle(fontSize: 24)),
// //                 onTap: () {
// //                   stop_timer();
// //                   set_new_sheet(0);
// //                   Navigator.pop(context);
// //                 },
// //               ),
// //             ),
// //             Visibility(
// //               visible: lock[1],
// //               child:
// //               ListTile(
// //                 title: const Text('練習 2', style: TextStyle(fontSize: 24)),
// //                 onTap: () {
// //                   stop_timer();
// //                   set_new_sheet(1);
// //                   Navigator.pop(context);
// //                 },
// //               ),
// //             ),
// //             Visibility(
// //               visible: lock[2],
// //               child:
// //               ListTile(
// //                 title: const Text('練習 3', style: TextStyle(fontSize: 24)),
// //                 onTap: () {
// //                   stop_timer();
// //                   set_new_sheet(2);
// //                   Navigator.pop(context);
// //                 },
// //               ),
// //             ),
// //             Visibility(
// //               visible: lock[3],
// //               child:
// //               ListTile(
// //                 title: const Text('練習 4', style: TextStyle(fontSize: 24)),
// //                 onTap: () {
// //                   stop_timer();
// //                   set_new_sheet(3);
// //                   Navigator.pop(context);
// //                 },
// //               ),
// //             ),
// //             Visibility(
// //               visible: lock[4],
// //               child:
// //               ListTile(
// //                 title: const Text('練習 5', style: TextStyle(fontSize: 24)),
// //                 onTap: () {
// //                   stop_timer();
// //                   set_new_sheet(4);
// //                   Navigator.pop(context);
// //                 },
// //               ),
// //             ),
// //             Visibility(
// //               visible: lock[5],
// //               child:
// //               ListTile(
// //                 title: const Text('練習 6', style: TextStyle(fontSize: 24)),
// //                 onTap: () {
// //                   stop_timer();
// //                   set_new_sheet(5);
// //                   Navigator.pop(context);
// //                 },
// //               ),
// //             ),
// //             Visibility(
// //               visible: lock[6],
// //               child:
// //               ListTile(
// //                 title: const Text('測驗', style: TextStyle(fontSize: 24)),
// //                 onTap: () {
// //                   stop_timer();
// //                   set_new_sheet(6);
// //                   Navigator.pop(context);
// //                 },
// //               ),
// //             ),
// //
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// // }
// //
// //
// // // class BluetoothApp extends StatefulWidget {
// // //   @override
// // //   _BluetoothAppState createState() => _BluetoothAppState();
// // // }
// // //
// // // class _BluetoothAppState extends State<BluetoothApp> {
// // //   // Initializing a global key, as it would help us in showing a SnackBar later
// // //   final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
// // //   // Get the instance of the bluetooth
// // //   FlutterBluetoothSerial bluetooth = FlutterBluetoothSerial.instance;
// // //
// // //   // Define some variables, which will be required later
// // //   List<BluetoothDevice> _devicesList = [];
// // //   BluetoothDevice? _device;
// // //   bool _connected = false;
// // //   bool _pressed = false;
// // //
// // //   @override
// // //   Widget build(BuildContext context) {
// // //     return Container(
// // //       // We have to work on the UI in this part
// // //     );
// // //   }
// // // }
// //
