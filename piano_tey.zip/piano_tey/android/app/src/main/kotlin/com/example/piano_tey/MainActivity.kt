package com.example.piano_tey

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
